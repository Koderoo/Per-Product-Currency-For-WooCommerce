=== Per Product Currency For WooCommerce ===
Contributors: Koderoo
Tags: woocommerce, currency, product price, custom currency, affiliate products
Requires at least: 4.7
Tested up to: 6.7
Stable tag: 1.4
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
The "Per Product Currency for WooCommerce" plugin allows you to set a custom currency for individual products in your WooCommerce store.